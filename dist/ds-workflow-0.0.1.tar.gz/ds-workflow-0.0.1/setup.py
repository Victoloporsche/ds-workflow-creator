from setuptools import setup, find_packages

setup(
    name='ds-workflow',
    version='0.0.1',
    description='Data Science end-to-end Workflow',
    author='Victor Uwaje',
    packages=find_packages(),
    license='MIT'
)