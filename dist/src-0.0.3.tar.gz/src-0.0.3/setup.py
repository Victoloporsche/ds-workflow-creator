from setuptools import setup, find_packages

setup(
    name='src',
    version='0.0.3',
    description='Data Science end-to-end Workflow',
    author='Victor Uwaje',
    packages=find_packages(),
    license='MIT'
)