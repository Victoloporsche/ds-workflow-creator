**Ds-Workflow-Creator**

The ds-workflow-creator automatically creates the directories and files needed
for end-to-end machine learning project.

**Installation**

`pip install ds-workflow`

**License**

MIT